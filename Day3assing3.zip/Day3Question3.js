    alert("cheking your grade by using if else statement!!");
let marks= prompt("enter your marks :");
console.log('your marks is ' + marks);

if(marks >= 70)
{
    console.log("GRADE : A+");
}

else if(marks >= 60 && marks < 70)
{
    console.log("GRADE : A");
}

else if(marks >= 50 && marks < 60)
{
    console.log("GRADE : B");
}

else if(marks >= 35 && marks < 50)
{
    console.log("GRADE : C");
}
else
{
console.log("FAIL!!");
}


//js file 




alert("checking your grade using ternary operators !!");

let mark= prompt("enter your marks :");
console.log('your marks is ' + mark);

let result = mark >= 70 ? ' GRADE : A+ ' : (mark >= 60 && mark < 70) ? ' GRADE : A ' :
 (mark >= 50 && mark < 60) ? ' GRADE : B ' : (mark >= 35 && mark < 50) ? ' GRADE : C ' :
  'FAIL !! ' ;

 console.log(result);


