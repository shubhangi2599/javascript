const student = {
    name: "Helsink",
    age: 24,
    projects: {
        diceGame: "Two player dice game using javascript"
    }
}
//destructuring the above object

const { name,age,projects:{diceGame}} = student;
console.log(name,age,diceGame) 
