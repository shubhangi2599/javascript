let shoppinglist = ['pizza','Pasta','french fries']
        console.log(shoppinglist)

        //copying the elements of shoopinglist array to shoppingbascket

        // adding new products to shoppingbascket array

        let shoppingbascket =['biscuits',...shoppinglist,'burger','chesse']
        console.log(shoppingbascket)