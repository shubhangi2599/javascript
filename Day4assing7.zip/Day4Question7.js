let num = prompt("enter a no : ")
let prime = function(num)
{
    if(num > 1)
    {
        for(i=2;i<=num;i++)
        {
            if((num%i)== 0)
               {
                console.log(num);
               }
            else
            {
                console.log("invalid");
            }
        }
    }
}