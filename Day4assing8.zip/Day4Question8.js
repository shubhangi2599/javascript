function ask(question,yes,no)
{
    if (confirm(question)) yes()
    else no();
}

/*ask("Do you agree?",
function() {alert("you agreed.");},
function() {alert("you canceled the execution."); }
);*/
//here now, we are using arrow functions...!!!!
ask(
    "Do you agree???",
    () =>alert("you agreed...!!!"),
    () => alert("you cancelled the execution..!!!"));