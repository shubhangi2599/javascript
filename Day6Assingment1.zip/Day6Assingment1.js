

let colours=['yellow','black','blue','brown','red'];
const list = document.querySelector('#list');
console.log(list);

colours.forEach(colour=>{
    list.innerHTML+=`<li>${colour}</li>`;
})

//to change the background color

const pg = document.getElementById('attribute');
console.log(pg.getAttribute('id'));

//setting time interval of 5 seconds
  
function f()
{            
pg.setAttribute('style','background-color:blue;')
}
