function multiplication()
{
let i=0;
let n=prompt("enter number:");
for(i=1;i<=10;i++)
{
    document.write(` ${+n} * ${i} = ${n * i}` );
    document.write("<br \>");
}
}